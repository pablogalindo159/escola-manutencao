# 🚀 Instalação - Live Streaming (YouTube)

## ✅ Pré-requisitos

- Laravel 10+
- PHP 8.2+
- PostgreSQL
- Account Google/YouTube

---

## 📦 PASSO 1: Instalar Dependências

### Laravel (Backend)

Não precisa instalar nada extra! A integração é 100% nativa do YouTube.

```bash
# Pronto para ir
composer install
```

### Flutter (Mobile)

Adicione ao `pubspec.yaml`:

```yaml
dependencies:
  flutter:
    sdk: flutter
  
  # Live Streaming
  youtube_player_flutter: ^8.1.0
  url_launcher: ^6.1.0
  intl: ^0.19.0
```

Depois:

```bash
flutter pub get
```

---

## 📁 PASSO 2: Adicionar Arquivos

### 1. Copiar Migration

```bash
cp mega-pack/live-streaming/2024_09_16_create_live_streams_table.php database/migrations/

php artisan migrate
```

### 2. Copiar Model

```bash
cp mega-pack/live-streaming/LiveStream.php app/Models/
```

### 3. Copiar Controller

```bash
cp mega-pack/live-streaming/LiveStreamController.php app/Http/Controllers/API/
```

### 4. Copiar Views Blade

```bash
cp mega-pack/live-streaming/live-stream-player.blade.php resources/views/
cp mega-pack/live-streaming/admin-live-streams.blade.php resources/views/
cp mega-pack/live-streaming/live-stream-form.blade.php resources/views/
```

### 5. Copiar Widget Flutter

```bash
cp mega-pack/live-streaming/live_stream_widget.dart lib/widgets/
```

---

## 🛣️ PASSO 3: Adicionar Rotas

Abra `routes/api.php` e adicione:

```php
// Rotas públicas
Route::prefix('live-streams')->group(function () {
    Route::get('/', [LiveStreamController::class, 'index']);
    Route::get('/live-now', [LiveStreamController::class, 'liveNow']);
    Route::get('/upcoming', [LiveStreamController::class, 'upcoming']);
    Route::get('/recent', [LiveStreamController::class, 'recent']);
    Route::get('/{id}', [LiveStreamController::class, 'show']);
    Route::get('/{id}/stats', [LiveStreamController::class, 'stats']);
});

// Rotas autenticadas (criador + admin)
Route::middleware(['auth:sanctum', 'teacher'])->prefix('live-streams')->group(function () {
    Route::post('/', [LiveStreamController::class, 'store']);
    Route::put('/{id}', [LiveStreamController::class, 'update']);
    Route::post('/{id}/start', [LiveStreamController::class, 'start']);
    Route::post('/{id}/end', [LiveStreamController::class, 'end']);
    Route::post('/{id}/archive', [LiveStreamController::class, 'archive']);
    Route::delete('/{id}', [LiveStreamController::class, 'destroy']);
});
```

---

## 🎯 PASSO 4: Usar no Laravel

### Criar Transmissão (por API)

```bash
curl -X POST http://localhost:8000/api/live-streams \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Live Q&A sobre Ar Condicionado",
    "description": "Vamos responder suas dúvidas",
    "scheduled_at": "2024-12-20 19:00:00",
    "course_id": "HVAC-101",
    "allow_chat": true,
    "recorded": true
  }'
```

### Adicionar Video ID (depois)

```bash
curl -X PUT http://localhost:8000/api/live-streams/1 \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "youtube_video_id": "dQw4w9WgXcQ"
  }'
```

### Iniciar Transmissão

```bash
curl -X POST http://localhost:8000/api/live-streams/1/start \
  -H "Authorization: Bearer YOUR_TOKEN"
```

### Finalizar Transmissão

```bash
curl -X POST http://localhost:8000/api/live-streams/1/end \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## 📱 PASSO 5: Usar no Flutter

### 1. Importar o Widget

```dart
import 'package:escolamanutencao/widgets/live_stream_widget.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class LiveStreamsPage extends StatefulWidget {
  @override
  State<LiveStreamsPage> createState() => _LiveStreamsPageState();
}

class _LiveStreamsPageState extends State<LiveStreamsPage> {
  List<Map<String, dynamic>> streams = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchStreams();
  }

  Future<void> _fetchStreams() async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost:8000/api/live-streams/live-now'),
        headers: {
          'Accept': 'application/json',
        },
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          streams = List<Map<String, dynamic>>.from(data['data'] ?? []);
          isLoading = false;
        });
      }
    } catch (e) {
      print('Erro ao buscar transmissões: $e');
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Transmissões ao Vivo'),
        backgroundColor: const Color(0xFF0066FF),
      ),
      body: LiveStreamsListWidget(
        streams: streams,
        isLoading: isLoading,
        onRefresh: _fetchStreams,
      ),
    );
  }
}
```

### 2. Exibir Transmissão Individual

```dart
LiveStreamWidget(
  streamId: '1',
  title: 'Live Q&A',
  description: 'Perguntas e respostas',
  professorName: 'João Silva',
  scheduledAt: DateTime.now(),
  status: 'live',
  viewersCount: 150,
  totalViewers: 250,
  likes: 45,
  allowChat: true,
  youtubeVideoId: 'dQw4w9WgXcQ',
)
```

---

## 🎬 PASSO 6: Criar Transmissão no YouTube

1. **Acesse** https://www.youtube.com/studio
2. **Clique** em "Criar" → "Começar uma transmissão ao vivo"
3. **Configure**:
   - Título: Ex "Live Q&A sobre Ar Condicionado"
   - Descrição: Qualquer uma
   - Categoria: Educação
   - Público: Unlisted (privada) ou Public
4. **Copie** o Video ID (aquela sequência no link)
5. **Cole** aqui na plataforma
6. **Inicie** a transmissão no YouTube
7. **Clique** em "Iniciar" na plataforma

---

## 📊 FLUXO COMPLETO

```
PROFESSOR
   ↓
Agendar aqui (data/hora/título)
   ↓
Ir no YouTube Studio
   ↓
Criar transmissão ao vivo (mesma data/hora)
   ↓
Copiar Video ID
   ↓
Voltar aqui, editar, colar Video ID
   ↓
No YouTube, iniciar transmissão
   ↓
Aqui, clicar "Iniciar" 🟢 LIVE
   ↓
ALUNOS VEEM AO VIVO no app/site
   ↓
No YouTube, finalizar transmissão
   ↓
Aqui, clicar "Finalizar" 🎬 GRAVAÇÃO SALVA NO YOUTUBE
```

---

## 🔐 Segurança

- ✅ Apenas professores podem criar transmissões
- ✅ Apenas criador ou admin podem editar
- ✅ Alunos veem apenas transmissões públicas
- ✅ Chat é gerenciado pelo YouTube (seguro)
- ✅ Video ID é opcional (pode adicionar depois)

---

## 🆘 Troubleshooting

### Video não aparece no player?
- Verificar se o Video ID está correto
- Recarregar página/app

### Chat não funciona?
- Certificar que `allow_chat = true`
- Chat é gerenciado 100% pelo YouTube, não aqui

### Não consigo iniciar transmissão?
- Certificar que `youtube_video_id` está preenchido
- Certificar que está logado como professor/admin

### Contadores não atualizam?
- Contadores públicos são 24h depois do YouTube
- Ele pega dados do YouTube API (gratuito)

---

## 🎓 Exemplo Completo

### Controller customizado

```php
<?php

namespace App\Http\Controllers\API;

use App\Models\LiveStream;
use App\Models\Course;

class LiveStreamController
{
    // ... código existente ...

    /**
     * Criar transmissão para um curso específico
     */
    public function createForCourse($courseId, Request $request)
    {
        $course = Course::findOrFail($courseId);
        
        $stream = LiveStream::create([
            'user_id' => auth()->id(),
            'title' => $request->title,
            'course_id' => $courseId,
            'scheduled_at' => $request->scheduled_at,
            'status' => 'scheduled',
        ]);

        return response()->json([
            'success' => true,
            'message' => "Transmissão agendada para o curso {$course->name}",
            'data' => $stream,
        ], 201);
    }

    /**
     * Obter transmissões de um curso
     */
    public function forCourse($courseId)
    {
        $streams = LiveStream::where('course_id', $courseId)
            ->with('user')
            ->orderBy('scheduled_at', 'desc')
            ->get();

        return response()->json([
            'success' => true,
            'count' => count($streams),
            'data' => $streams,
        ]);
    }
}
```

Adicione as rotas:

```php
Route::prefix('courses/{courseId}/live-streams')->group(function () {
    Route::get('/', [LiveStreamController::class, 'forCourse']);
    Route::post('/', [LiveStreamController::class, 'createForCourse'])
        ->middleware(['auth:sanctum', 'teacher']);
});
```

---

## 📚 Links Úteis

- [YouTube API Docs](https://developers.google.com/youtube/v3)
- [Laravel Documentation](https://laravel.com/docs)
- [Flutter YouTube Player](https://pub.dev/packages/youtube_player_flutter)
- [YouTube Studio](https://www.youtube.com/studio)

---

## ✨ Pronto!

Sua plataforma agora suporta transmissões ao vivo do YouTube! 🎉

Qualquer dúvida, é só chamar. Bora codar! 🚀
