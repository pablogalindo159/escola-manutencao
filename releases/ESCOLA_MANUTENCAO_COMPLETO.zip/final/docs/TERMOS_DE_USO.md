# 📋 TERMOS DE USO - ESCOLA DA MANUTENÇÃO

**Data de Vigência**: 16 de Setembro de 2026  
**Plataforma**: escoladamanutencao.com.br  
**Proprietário**: [Seu Nome/Empresa]

---

## 1️⃣ CONTEÚDO PROTEGIDO

Todos os vídeos, materiais educacionais e recursos disponibilizados na plataforma Escola da Manutenção são **conteúdo protegido por direitos autorais**.

### 1.1 Seus Direitos
- ✅ Assistir aos vídeos através do app/website
- ✅ Acessar apenas com sua conta pessoal
- ✅ Usar para aprendizado pessoal
- ✅ Baixar certificados

### 1.2 Proibições
- ❌ **COMPARTILHAR** sua conta com outras pessoas
- ❌ **DISTRIBUIR** links de acesso
- ❌ **FAZER DOWNLOAD** dos vídeos
- ❌ **GRAVAR** a tela enquanto assiste
- ❌ **CAPTURAR** screenshot/fotos
- ❌ **REGRAVAR** ou **REEDITAR** o conteúdo
- ❌ **VENDER** ou **LUCRAR** com o conteúdo
- ❌ **PUBLICAR** em outras plataformas (YouTube, TikTok, etc)
- ❌ **COMPARTILHAR** em redes sociais, grupos ou chats

---

## 2️⃣ MONITORAMENTO E SEGURANÇA

A plataforma utiliza **sistemas automáticos de segurança** para proteger o conteúdo:

### 2.1 Detecção Automática
```
✓ Monitora múltiplos IPs simultâneos
✓ Detecta compartilhamento de conta
✓ Rastreia tentativas de download
✓ Bloqueia acesso suspeito
```

### 2.2 Bloqueios Automáticos
- **Acesso de múltiplos IPs em < 5 minutos**: Bloqueio automático por 1 hora
- **Tentativas de download**: Conta bloqueada imediatamente
- **Taxa de requisições elevada**: Rate limiting automático
- **Comportamento suspeito**: Análise manual

---

## 3️⃣ CONSEQUÊNCIAS DE VIOLAÇÃO

### 3.1 Primeira Violação
```
⚠️ Aviso por email
🔓 Conta desbloqueada após 24 horas
💬 Contato direto para esclarecimento
```

### 3.2 Segunda Violação
```
🔒 Conta bloqueada por 7 dias
💰 Sem reembolso
📧 Email de aviso formal
```

### 3.3 Terceira Violação
```
❌ Conta permanentemente bloqueada
💰 Sem reembolso
⚖️ Possível ação legal
```

---

## 4️⃣ AÇÕES LEGAIS

Violações graves podem resultar em:

### 4.1 Responsabilidade Civil
- Indenização por lucros cessantes
- Indenização por danos morais
- Indenização por danos materiais

### 4.2 Responsabilidade Criminal (Lei 9.610/98)
```
Artigo 101 - Violação de direitos autorais:
Pena: Detenção de 3 meses a 1 ano + multa
```

### 4.3 Ação Judicial
- Processo judicial na justiça cível
- Bloqueio de dispositivos
- Multa por violação (até R$ 50.000)

---

## 5️⃣ EXEMPLO DE VIOLAÇÕES

### ❌ PROIBIDO

```
"Vou baixar o vídeo com OBS Studio"
→ Bloqueio automático

"Vou compartilhar minha conta com meu amigo"
→ Detecção de IP múltiplo → Bloqueio

"Vou mandar o vídeo pro WhatsApp"
→ Rastreamento de distribuição → Ação legal

"Vou postar no YouTube"
→ DMCA takedown + Processo judicial

"Vou fazer print da tela"
→ Bloqueio automático de screenshot
```

### ✅ PERMITIDO

```
"Vou assistir o vídeo na minha conta"
→ OK

"Vou fazer anotações do que aprendi"
→ OK

"Vou usar o conhecimento para reparar ar condicionado"
→ OK

"Vou indicar a plataforma para meus amigos"
→ OK (eles compram sua própria conta)

"Vou baixar meu certificado"
→ OK
```

---

## 6️⃣ PRIVACIDADE E DADOS

### 6.1 O que Coletamos
```
✓ Email e dados de perfil
✓ Histórico de acessos
✓ IP e device ID
✓ Padrão de visualização
✓ Interações (likes, comentários)
```

### 6.2 Para que Usamos
```
✓ Personalizar sua experiência
✓ Melhorar a plataforma
✓ Detectar fraudes e abuso
✓ Enviar notificações
```

### 6.3 Não Vendemos Dados
```
✗ Dados nunca são vendidos
✗ Dados nunca são compartilhados
✗ Dados são 100% privados
```

---

## 7️⃣ REEMBOLSO E DEVOLUÇÕES

### 7.1 Reembolso Normal
- ✅ Até 7 dias da compra: Reembolso total
- ✅ Sem perguntas ou condições

### 7.2 Sem Reembolso
- ❌ Após 7 dias: Sem reembolso
- ❌ Conta bloqueada: Sem reembolso
- ❌ Violação de termos: Sem reembolso

---

## 8️⃣ MUDANÇAS NOS TERMOS

Podemos alterar estes termos a qualquer momento:
- 📧 Avisaremos por email
- 📱 Aviso na plataforma
- 📅 Com 30 dias de antecedência

Continuando a usar = você concorda

---

## 9️⃣ SUPORTE E DÚVIDAS

**Email:** suporte@escoladamanutencao.com.br  
**WhatsApp:** (41) 98765-4321  
**Horário:** Segunda a Sexta, 9h-18h

### Dúvidas Comuns

**P: Posso compartilhar a tela com meu colega durante a aula?**  
R: Não. Cada pessoa precisa de sua própria conta.

**P: Posso baixar para assistir offline?**  
R: Não. O app faz cache automático (pequeno), mas não download completo.

**P: E se meu IP mudar (móvel para Wi-Fi)?**  
R: OK! Sistema permite mudança de IP a cada 5 minutos. Só bloqueia se mudar muito rápido (suspeita de compartilhamento).

**P: Fui bloqueado. Como desbloquear?**  
R: Email para suporte@escoladamanutencao.com.br explicando a situação.

**P: Posso usar em 2 dispositivos?**  
R: Sim! Mas do mesmo IP. Se mudar de IP, espere 5 minutos antes de acessar em outro dispositivo.

---

## 🔟 ACEITAÇÃO

Ao se cadastrar na Escola da Manutenção, você:

```
✅ Declara ter lido estes termos
✅ Concorda com todas as condições
✅ Entende as consequências de violação
✅ Autoriza monitoramento automático
✅ Aceita ações legais se violado
```

**Timestamp de Aceição:**  
Data: ________________  
Hora: ________________  
IP: ________________  
Device: ________________

---

## ⚖️ JURISDIÇÃO

Estes termos são regidos pela **Lei Brasileira**:
- Lei 9.610/98 (Direitos Autorais)
- Lei 8.078/90 (Proteção ao Consumidor)
- Lei 12.965/14 (Marco Civil da Internet)

Foro competente: **Paraná, Brasil**

---

**ASSINADO DIGITALMENTE**

```
Nome: _________________________
Email: _________________________
Data: __________________________
Aceito os termos: ☑️ Sim
```

---

**Por favor, compartilhe este documento com seus alunos antes de qualquer acesso!**

---

## 📞 CONTATO LEGAL

**Proprietário:** [Seu Nome Completo]  
**Documento:** [CPF/CNPJ]  
**Email Legal:** legal@escoladamanutencao.com.br  
**Telefone:** (41) 98765-4321  
**Endereço:** [Seu Endereço Profissional]

---

**Versão 1.0 | Última atualização: 16/09/2026**
