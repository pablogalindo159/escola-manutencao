# 🎨 Guia Visual Completo - Escola da Manutenção

## 📱 APLICATIVO FLUTTER

### Telas Implementadas

#### 1. **Splash Screen**
- **Função**: Tela de carregamento inicial
- **Design**: Gradient azul (0066FF → 0052CC)
- **Elementos**: Logo + nome + loader animado
- **Tempo de exibição**: 2-3 segundos
- **Transição**: Fade para Login (se deslogado) ou Home (se logado)

#### 2. **Login Screen**
- **Email/CPF**: Campo validado
- **Senha**: Campo com toggle visibilidade
- **Botão**: "Entrar" (azul primário)
- **Links**: "Esqueci minha senha" + "Criar conta"
- **Social**: Login com Google (botão branco)
- **Validação**: Feedback em tempo real

#### 3. **Register Screen**
- **Campos**: Nome, Email, CPF, Senha, Confirmação
- **Validação**: Máscaras (CPF), confirmação de senha
- **Termos**: Checkbox + link
- **Erro**: Mensagens inline vermelhas
- **Sucesso**: Redirect para login

#### 4. **Home Screen** ⭐ Principal
- **Header Gradient**: Azul (0066FF)
- **Dados Aluno**: Nome, nível, pontos
- **Widgets**:
  - Card Progresso (barra com %)
  - Card Cursos em Andamento (lista)
  - Card Meus Reparos (contadores)
  - Card Comunidade (posts recentes)
- **Bottom Nav**: 4 abas (Home/Cursos/Reparos/Perfil)

#### 5. **Course List Screen**
- **Layout**: Grid de cards 2x2
- **Card Elemento**:
  - Ícone/imagem (120x80px)
  - Título (max 20 caracteres)
  - Duração
  - Preço
  - Badge "Novo" ou "Popular"
- **Filtros**: Top (Todos, Iniciante, Avançado, Premium)
- **Search**: Barra superior

#### 6. **Course Detail Screen**
- **Header**: Imagem + gradient overlay
- **Info**:
  - Título, professor, duração
  - Descrição completa
  - 4 primeiras aulas listadas
- **Progresso**: Barra de progresso
- **Botão CTA**: "Começar" ou "Continuar"

#### 7. **Video Player Screen**
- **Player**: Vídeo responsivo (16:9)
- **Controles**: Play/pause/seek/volume
- **Lado direito**: Lista de vídeos (scrollable)
- **Info abaixo**: Descrição, transcrição, comentários
- **Botão**: "Marcar como concluído" (verde)

#### 8. **Course Progress Screen**
- **Aulas Completadas**: Lista com ✅ checkmarks
- **Aulas Faltando**: Com 🔒 lock
- **Certificado**: Botão "Solicitar Certificado" (quando 100%)
- **QR Code**: Certificado com QR escaneável

#### 9. **Repairs List Screen**
- **Header Gradient**: Vermelho (FF6B6B)
- **Filtros**: Todos, Em Andamento, Aprovados, Rejeitados
- **Card Reparo**:
  - Título equipamento
  - Status badge (cores)
  - Defeito descrito
  - Barra progresso (estágios)
  - Contador de fotos
- **Botão Flutuante**: "+" para novo reparo

#### 10. **Repair Form Screen**
- **Campos**:
  - Tipo de equipamento (dropdown)
  - Cliente (nome + contato)
  - Defeito (textarea)
  - Diagnóstico (textarea)
  - Medições (JSON key-value)
  - Componentes (JSON array)
  - **Fotos**: 4 slots (antes/durante/depois/diagnóstico)
- **Upload Fotos**: Câmera + galeria
- **Compressão**: Automática 85%
- **Validação**: Tous os campos obrigatórios
- **Botão**: "Enviar para Review" (gradiente verde)

#### 11. **Repair Photo Screen**
- **Câmera**: Preview em tempo real
- **Botões**: Tirar foto / Usar câmera frontal
- **Crop**: Editor simples (zoom, rotação)
- **Compressão**: Status visual
- **Salvar**: Confirma slot de foto

#### 12. **Repair Detail Screen**
- **Status Grande**: Badge colorida topo
- **Fotos**: Carrossel 4 imagens
- **Dados**: Equipamento, cliente, defeito, diagnóstico
- **Medições/Componentes**: Expandíveis
- **Feedback Professor**: 
  - Avatar professor
  - Texto comentário
  - Rating ⭐ (1-5)
- **Ações**: Download PDF ou compartilhar

#### 13. **Posts Screen (Comunidade)**
- **Header Gradient**: Roxo (7B68EE)
- **Botão "Novo Post"**: Flutuante canto inferior
- **Card Post**:
  - Avatar + nome autor + timestamp
  - Texto post
  - Contador likes + comentários
  - Botões: ❤️ like, 💬 comentar, ⋮ menu
- **Scroll**: Infinito (pagination)
- **Like animado**: Coração explode

#### 14. **Post Detail Screen**
- **Post expandido**: Tema claro
- **Comentários**: Lista com avatares
- **Campo**: "Adicione um comentário..."
- **Responder**: Indentação visual
- **Like**: Marcar/desmarcar

#### 15. **Post Form Screen**
- **Editor**: TextArea grande (250 max)
- **Imagens**: Até 3, grid 3x3 thumbnails
- **Emoji picker**: Ícone emoji
- **Preview**: Card ao lado
- **Botão**: "Publicar" (roxo primário)

#### 16. **Profile Screen**
- **Header**: Avatar grande + nome + nível
- **Stats**: Cursos, reparos, posts em grid 3x3
- **Menu**:
  - 📚 Meus cursos
  - 🔨 Meus reparos
  - 💬 Minha comunidade
  - ⭐ Meus certificados
  - ⚙️ Configurações
  - 🚪 Sair
- **Avatar Edit**: Foto + câmera
- **Tema**: Dark/Light toggle

---

## 🎯 Design System

### Cores

| Componente | Cor | HEX | Uso |
|-----------|-----|-----|-----|
| **Primary** | Azul | `#0066FF` | Botões, headers, links |
| **Primary Dark** | Azul Escuro | `#0052CC` | Gradients, hover |
| **Secondary** | Vermelho | `#FF6B6B` | Status, atenção |
| **Success** | Verde | `#51CF66` | Aprovações, sucesso |
| **Warning** | Amarelo | `#FFC107` | Pendências, atenção |
| **Danger** | Vermelho Escuro | `#FA5252` | Erros, rejeições |
| **Purple** | Roxo | `#7B68EE` | Comunidade, destaque |
| **Background** | Cinza Claro | `#F5F5F5` | Canvas |
| **Card BG** | Branco | `#FFFFFF` | Cards, modais |
| **Text Primary** | Cinza Escuro | `#2C2C2A` | Texto corpo |
| **Text Secondary** | Cinza Médio | `#888780` | Labels, hints |

### Tipografia

```
Poppins (Google Fonts)
- Weights: 400, 500, 600, 700

Tamanhos:
- H1: 28px • 600 weight • Primary color
- H2: 22px • 600 weight • Primary color
- H3: 18px • 500 weight • Primary color
- Body: 16px • 400 weight • Text primary
- Small: 14px • 400 weight • Text secondary
- Micro: 12px • 400 weight • Text muted
- Caption: 10px • 400 weight • Text muted

Line Height: 1.5 padrão
Letter Spacing: 0 (normal)
```

### Components Reutilizáveis

#### Button
```dart
- Primary: Azul fundo, branco texto
- Secondary: Branco fundo, azul texto, borda 1px azul
- Tertiary: Transparente, azul texto
- Disabled: Cinza 50%, cursor not-allowed
- Loading: Spinner inside
- Size: Small (36px), Medium (44px), Large (52px)
```

#### Card
```dart
- Background: Branco
- Border Radius: 12px
- Box Shadow: 0 2px 8px rgba(0,0,0,0.08)
- Padding: 16px
- Border: 0.5px #E0E0E0
```

#### Badge
```dart
- Background: Role tint (azul, verde, vermelho)
- Text: Role dark (role color mais escuro)
- Padding: 4px 12px
- Border Radius: 6px
- Font Size: 11px
- Font Weight: 500
```

#### Input
```dart
- Height: 48px
- Border: 0.5px #E0E0E0
- Border Radius: 8px
- Padding: 12px 16px
- Font Size: 14px
- Focus: Azul 2px border, shadow subtle
- Placeholder: Text secondary color
```

#### BottomNavigationBar
```dart
- 4 items (Home, Courses, Repairs, Profile)
- Icons Tabler 24px
- Label: 10px small
- Active: Azul + ícone filled
- Inactive: Cinza + ícone outline
- Height: 64px
```

---

## 🌐 WEBSITE

### Tecnologia
- **Framework**: Laravel Blade + Tailwind CSS
- **Assets**: CDN Bootstrap Icons
- **Responsivo**: Mobile-first, breakpoints: 480px, 768px, 1024px, 1400px

### Páginas Principais

#### 1. **Landing Page** ⭐
```
Header:
  Logo + Navegação (Cursos, Sobre, Contato, Login)
  
Hero Section:
  - Título: "Domine a Manutenção Industrial"
  - Subtitle: "Cursos práticos com certificados oficiais"
  - CTA: "Começar Agora" (azul primário, grande)
  - Background: Gradient azul (0066FF → 0052CC)
  - Imagem direita: Tecnologia/mecânica
  
Seção Destaque:
  - 4 cards cursos populares (grid 2x2)
  - Ícone, título, duração, preço, botão "Saiba Mais"
  
Seção Stats:
  - Número alunos (1.234+)
  - Número cursos (8)
  - Taxa conclusão (72%)
  - Card layout: 3 colunas
  
Seção Depoimentos:
  - 3 cards com avatar, nome, função, texto
  - Estrelas (⭐ x5)
  
CTA Final:
  - "Pronto para começar?"
  - Botão grande "Criar Conta Grátis"
  
Footer:
  - Links: Privacidade, Termos, Contato
  - Copyright © 2026
  - Social icons (links)
```

#### 2. **Página Cursos**
```
Header:
  - Título "Catálogo de Cursos"
  - Busca (search bar)
  
Filtros Lateral (768px+) ou Horizontal (<768px):
  - Categorias (checkboxes)
  - Nível (Iniciante, Intermediário, Avançado)
  - Preço (slider)
  - Ordenação (Novo, Popular, Preço)
  
Grid Cursos:
  - 3 colunas (1400px+)
  - 2 colunas (768px-1400px)
  - 1 coluna (<768px)
  - Card: thumbnail, título, professor, ⭐ rating, duração, preço
  - Hover: Elevação + botão "Ver Detalhes" revela
  
Paginação:
  - Botões < > ou números
  - "Mostrando 1-12 de 48"
```

#### 3. **Detalhe Curso**
```
Header:
  - Imagem curso (hero 600x300px)
  - Gradient overlay
  - Título, professor, ⭐ rating, #alunos
  
Left Column (1024px+) / Full Stack (<1024px):
  Descrição:
    - Texto completo
    - O que vai aprender (bulleted list)
    - Requisitos
  
  Aulas:
    - Aula 1: "Introdução" [14 min]
      └─ Vídeo preview + descrição curta
    - Aula 2: "Fundamentos" [22 min]
      └─ [Locked 🔒] - Libera após aula 1
    
Right Column / Below:
  Card Compra:
    - Preço destaque (R$ 49,90/mês)
    - "COMEÇAR AGORA" (botão azul grande)
    - Inclui: ✅ Certificado, ✅ Acesso vitalício, ✅ Suporte
    - Ou "Assista a Amostra Grátis"
  
  Instrutor Card:
    - Avatar, nome, função
    - Bio (2-3 linhas)
    - Social links
```

#### 4. **Admin Dashboard** 📊
```
Header:
  - Logo + "Admin Dashboard"
  - Perfil usuário (avatar, dropdown logout)
  
Sidebar (1024px+) / Hamburger (<1024px):
  - Dashboard (ativo)
  - Usuários
  - Cursos
  - Pagamentos
  - Relatórios
  - Configurações
  - Sair
  
Main Content:
  Top Metrics (4 cards):
    [ Alunos Ativos: 1,234 ] [ Receita: R$ 24.580 ]
    [ Cursos Ativos: 8 ]     [ Taxa Conclusão: 72% ]
  
  Chart Section:
    - Gráfico linha: Inscrições últimos 30 dias
    - Gráfico pizza: Cursos por categoria
  
  Tabelas:
    1. Últimas Inscrições (10 rows)
       Colunas: Nome, Email, Curso, Data, Status, Ações
    
    2. Receita Últimos 7 Dias
       Colunas: Data, Alunos, Receita, Método, Status
  
  Botões Ação:
    - Exportar CSV
    - Filtrar datas
    - Refresh
```

#### 5. **Painel Aluno (Perfil)**
```
Top Section:
  Avatar grande (120x120px)
  Nome, nível, pontos
  Botão editar perfil
  
Stats Grid (3 cols):
  [ Cursos: 3 ] [ Reparos: 12 ] [ Posts: 8 ]
  
Menu Opções:
  - Meus Cursos (link)
  - Meus Reparos (link)
  - Minha Comunidade (link)
  - Certificados (link)
  - Configurações (link)
  
Cursos Inscritos:
  Cards grid: thumbnail + título + progresso barra
  
Últimas Atividades:
  Timeline: "Completou Refrigeração • 2 dias atrás"
           "Postou na comunidade • 1 dia atrás"
```

#### 6. **Painel Professor**
```
Metrics:
  [ Total Alunos: 245 ] [ Reparos Pendentes: 8 ]
  [ Média Rating: 4.8/5 ] [ Alunos Ativos: 203 ]
  
Reparos em Review:
  Lista cards com:
    - Nome aluno
    - Equipamento
    - Status badge
    - 4 thumbs fotos
    - Botões: Aprovar, Recusar, Detalhes
  
  Modal ao clicar "Detalhes":
    - Fotos carrossel (lightbox)
    - Diagnóstico texto
    - Campo feedback + rating
    - Botões ação
  
Minhas Aulas:
  Tabela: Título, Durações, #Videos, Alunos Inscritos
  
Relatório:
  Gráfico: Taxa conclusão por semana
  Top performers: Avatar + nome + %progresso
```

---

## 🎬 Animações & Transições

### Micro-Interactions
```
✓ Botão hover: Scale 1.02 + sombra
✓ Input focus: Border color change + glow 2px
✓ Card hover: Elevação +4px (translate Y -4px)
✓ Like button: Coração escala 1.2 + 0.3s easeOut
✓ Toast appear: Slide in from bottom 300ms
✓ Modal: Fade 200ms + scale 0.95→1.0
✓ Progressbar: Linear progress 1.5s
✓ Loading spinner: Rotate 2s infinite
```

### Page Transitions
```
✓ Fade: 200ms (telas de info)
✓ Slide: 300ms (menu)
✓ Scale: 250ms (modals)
```

---

## 📐 Layout Grid

### Mobile (Flutter)
```
Safe area: 16px padding sides
Grid: 1 column
Bottom nav: 64px height
Max width: 100% (device width)
```

### Website
```
Container: 1400px max-width, centered
Padding: 16px mobile, 24px tablet, 48px desktop

Grid System:
- 12 columns
- Gap: 24px
- Breakpoints: 480px, 768px, 1024px, 1400px

Cards:
- 3 cols (1024px+)
- 2 cols (768px-1024px)
- 1 col (<768px)
```

---

## 🔐 Modo Dark

```
Implementação: CSS variables + prefers-color-scheme
Fallback: Modo claro padrão

Cores (dark mode):
- Background: #0b0b0b
- Surface 1: #1a1a1a
- Surface 2: #262626
- Text Primary: #ffffff
- Text Secondary: #a0a0a0
- Accent: #3b9eff (azul mais claro)
```

---

## ✨ Diferenças App vs Website

| Aspecto | App Flutter | Website |
|---------|------------|---------|
| **Navigation** | Bottom nav 4 abas | Sidebar + header |
| **Cards** | 1-2 colunas | 2-3 colunas |
| **Formulários** | Stack vertical | Grid responsivo |
| **Fotos** | Câmera integrada | Upload file |
| **Notificações** | Push FCM | Toast/Bell |
| **Authenticação** | Biometria | Email/senha |
| **Tema** | Light/Dark | Light (dark em dev) |
| **Transições** | Smooth 300ms | 200ms fade |

---

## 📦 Assets

### Icons (Tabler Icons)
```
ti-home, ti-book, ti-wrench, ti-users, ti-user, ti-camera,
ti-heart, ti-heart-filled, ti-star, ti-star-filled, ti-settings,
ti-edit, ti-trash, ti-download, ti-share, ti-search, ti-plus,
ti-close, ti-check, ti-menu, ti-arrow-right
```

### Fonts
```
Google Fonts:
- Poppins (400, 500, 600, 700) → Títulos + UI
- Inter (400) → Body text

Fallbacks: -apple-system, BlinkMacSystemFont, Segoe UI
```

### Images
```
Cursos: 
  - refrigeração.png (120x80px)
  - pneumática.png
  - eletrônica.png
  - hidráulica.png
  - etc.

Hero:
  - landing-hero.png (1400x600px)
  - course-hero.jpg

Avatares:
  - user-default.svg (initials avatar)
```

---

## 🎯 Checklist Implementação Visual

### App Flutter
- [ ] Cores definidas em theme.dart
- [ ] Tipografia em TextTheme
- [ ] Components reutilizáveis (button.dart, card.dart)
- [ ] Bottom nav com 4 rotas
- [ ] Dark mode suportado
- [ ] Responsivo (portrait/landscape)
- [ ] Material Design 3
- [ ] Animações smooth (300ms padrão)

### Website
- [ ] Header + navigation sticky
- [ ] Footer em todas as páginas
- [ ] Breadcrumbs nas páginas internas
- [ ] Search funcional
- [ ] Filtros dinâmicos
- [ ] Responsive design (mobile-first)
- [ ] Dark mode (opcional)
- [ ] Accessibility (WCAG AA)
- [ ] Performance (Lighthouse 90+)

---

## 📱 Exemplo Layout Mobile vs Desktop

### Mobile (375px)
```
┌──────────────────┐
│   Header Nav     │
├──────────────────┤
│                  │
│   Hero Section   │
│    (100% width)  │
│                  │
├──────────────────┤
│                  │
│   Cards (1col)   │
│   Cards (1col)   │
│                  │
├──────────────────┤
│   Footer         │
├──────────────────┤
│  Bottom Nav      │
└──────────────────┘
```

### Desktop (1400px)
```
┌────────────────────────────────────────────────────┐
│   Logo  │  Nav  │  Search  │  Profile  │  Login   │
├──────────────────────────────────────────────────┬─┤
│                                                  │ │
│         Hero Section (hero image)                │S│
│                                                  │i│
├──────────────────────────────────────────────────┤d│
│  Card 1      │ Card 2       │ Card 3              │e│
│  Card 4      │ Card 5       │ Card 6              │b│
├──────────────────────────────────────────────────┤a│
│         Stats Section (3 cols)                   │r│
├──────────────────────────────────────────────────┤ │
│                                                  │ │
│         Footer                                   │ │
└──────────────────────────────────────────────────┴─┘
```

---

## 🎨 Gerador de Cores

Usar https://coolors.co para validar paleta:
- Contraste AAA: Todos os textos
- Harmonia: Cores complementares
- Acessibilidade: Simular daltonismo

---

**Última atualização**: 2026-09-16
**Versão**: 1.0.0
**Status**: ✅ PRONTO PARA IMPLEMENTAÇÃO

