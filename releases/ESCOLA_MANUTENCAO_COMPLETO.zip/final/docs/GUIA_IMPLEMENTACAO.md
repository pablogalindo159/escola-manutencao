# 🔒 GUIA DE IMPLEMENTAÇÃO - PROTEÇÃO DE VÍDEOS

**Status:** ✅ Pronto para usar  
**Tempo de implementação:** 2-3 horas  
**Complexidade:** Média  

---

## 📦 ARQUIVOS ENTREGUES

```
video-protection/
├── VideoStreamController.php         (Backend - streaming seguro)
├── secure_video_player.dart          (Flutter - player customizado)
├── routes-video-protection.php       (Rotas API)
├── TERMOS_DE_USO.md                  (Contrato legal)
└── GUIA_IMPLEMENTACAO.md             (este arquivo)
```

---

## 🚀 PASSO 1: COPIAR ARQUIVOS

### Backend (Laravel)

```bash
# Controller
cp video-protection/VideoStreamController.php \
   app/Http/Controllers/API/

# Rotas (adicionar ao final de routes/api.php)
cat video-protection/routes-video-protection.php >> routes/api.php
```

### Flutter

```bash
# Widget
cp video-protection/secure_video_player.dart \
   lib/widgets/

# Adicionar dependências no pubspec.yaml
flutter pub add flutter_screenprotector
flutter pub add chewie
flutter pub add video_player
```

---

## 🛠️ PASSO 2: CONFIGURAR BACKEND

### 2.1 Adicionar Model (se não existe)

```php
<?php
// app/Models/Video.php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Video extends Model
{
    protected $fillable = [
        'course_id',
        'title',
        'description',
        'file_path',
        'duration',
        'quality',
    ];

    public function course()
    {
        return $this->belongsTo(Course::class);
    }
}
```

### 2.2 Atualizar Model User

```php
<?php
// app/Models/User.php

public function hasActiveSubscription($course)
{
    return $this->subscriptions()
        ->where('course_id', $course->id)
        ->where('expires_at', '>', now())
        ->exists();
}

public function hasPurchasedCourse($courseId)
{
    return $this->payments()
        ->where('course_id', $courseId)
        ->where('status', 'approved')
        ->exists();
}
```

### 2.3 Verificar Storage

```bash
# Certificar que pasta videos existe
mkdir -p storage/app/videos

# Dar permissão de leitura
chmod 755 storage/app/videos
```

### 2.4 Testar Rotas

```bash
# Verificar se rotas foram adicionadas
php artisan route:list | grep stream

# Deve aparecer:
# GET /api/videos/{id}/stream-url
# GET /videos/{id}/stream
# GET /admin/videos/{id}/access-log
# POST /admin/users/{id}/block-stream
```

---

## 📱 PASSO 3: CONFIGURAR FLUTTER

### 3.1 Adicionar Widget ao App

```dart
// lib/screens/video_detail_screen.dart

import 'package:escolamanutencao/widgets/secure_video_player.dart';

class VideoDetailScreen extends StatelessWidget {
  final String videoId;
  final String videoTitle;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.grey[900],
        title: Text(videoTitle),
      ),
      body: SecureVideoPlayer(
        videoId: videoId,
        videoTitle: videoTitle,
        // authToken é obtido automaticamente do secure storage
      ),
    );
  }
}
```

### 3.2 Configurar Interceptor JWT

```dart
// lib/services/api_service.dart

class ApiService {
  final Dio _dio = Dio();

  ApiService() {
    // Interceptor para adicionar token JWT automaticamente
    _dio.interceptors.add(
      InterceptorsWrapper(
        onRequest: (options, handler) async {
          final token = await _getToken();
          options.headers['Authorization'] = 'Bearer $token';
          return handler.next(options);
        },
      ),
    );
  }

  Future<String> _getToken() async {
    const storage = FlutterSecureStorage();
    return await storage.read(key: 'auth_token') ?? '';
  }
}
```

### 3.3 Adicionar Dependências

```yaml
# pubspec.yaml

dependencies:
  flutter:
    sdk: flutter
  
  # Vídeo
  video_player: ^2.7.0
  chewie: ^1.7.0
  
  # Segurança
  flutter_secure_storage: ^9.0.0
  flutter_screenprotector: ^1.0.0
  
  # Network
  dio: ^5.3.0
  
  # Estado
  provider: ^6.0.0
```

```bash
flutter pub get
```

---

## 🔐 PASSO 4: IMPLEMENTAR TERMOS DE USO

### 4.1 Criar Migration para Aceição

```bash
php artisan make:migration create_terms_acceptance_table
```

```php
<?php
// database/migrations/2024_09_16_create_terms_acceptance_table.php

Schema::create('terms_acceptances', function (Blueprint $table) {
    $table->id();
    $table->foreignId('user_id')->constrained();
    $table->string('terms_version');
    $table->timestamp('accepted_at');
    $table->string('ip_address');
    $table->string('user_agent');
    $table->timestamps();
    
    $table->unique(['user_id', 'terms_version']);
});
```

```bash
php artisan migrate
```

### 4.2 Criar Controller para Aceição

```php
<?php
// app/Http/Controllers/TermsController.php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TermsController extends Controller
{
    public function acceptTerms(Request $request)
    {
        auth()->user()->termAcceptances()->create([
            'terms_version' => '1.0',
            'ip_address' => $request->ip(),
            'user_agent' => $request->userAgent(),
            'accepted_at' => now(),
        ]);

        return response()->json([
            'success' => true,
            'message' => 'Termos aceitos com sucesso',
        ]);
    }

    public function hasAcceptedTerms(Request $request)
    {
        return response()->json([
            'accepted' => auth()->user()
                ->termAcceptances()
                ->where('terms_version', '1.0')
                ->exists(),
        ]);
    }
}
```

### 4.3 Adicionar Rota

```php
// routes/api.php

Route::middleware(['auth:sanctum'])->group(function () {
    Route::post('/terms/accept', [TermsController::class, 'acceptTerms']);
    Route::get('/terms/accepted', [TermsController::class, 'hasAcceptedTerms']);
});
```

### 4.4 Mostrar Modal no App

```dart
// lib/screens/home_screen.dart

class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    _checkTermsAcceptance();
  }

  Future<void> _checkTermsAcceptance() async {
    final hasAccepted = await _apiService.hasAcceptedTerms();
    
    if (!hasAccepted) {
      _showTermsModal();
    }
  }

  void _showTermsModal() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Text('Termos de Uso'),
        content: SingleChildScrollView(
          child: Text(
            '''Você aceita os termos de uso da Escola da Manutenção?

- Conteúdo é protegido por direitos autorais
- Download é proibido
- Compartilhamento é proibido
- Violações resultam em bloqueio de conta''',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Não aceito'),
          ),
          ElevatedButton(
            onPressed: () {
              _apiService.acceptTerms();
              Navigator.pop(context);
            },
            child: const Text('Aceito'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // ... resto do código
  }
}
```

---

## ✅ PASSO 5: TESTAR

### 5.1 Testar Backend

```bash
# Iniciar server
php artisan serve

# Testar obtenção de token
curl -X POST http://localhost:8000/api/login \
  -d "email=teste@exemplo.com&password=senha123"

# Testar obtenção de URL de stream
curl -X GET http://localhost:8000/api/videos/1/stream-url \
  -H "Authorization: Bearer TOKEN_AQUI"

# Deve retornar:
{
  "success": true,
  "data": {
    "stream_url": "http://localhost:8000/videos/1/stream?token=xyz",
    "expires_in": 3600
  }
}
```

### 5.2 Testar Flutter

```bash
# Executar app
flutter run

# Verificar logs
flutter logs

# Deve aparec: "Stream iniciado" + user_id + video_id
```

### 5.3 Testar Proteção

```bash
# Tentar acessar stream SEM token
curl http://localhost:8000/videos/1/stream
# → Erro 401: Token obrigatório

# Tentar acessar com IP diferente
# → Erro 403: IP diferente

# Tentar rate limiting (5+ req/min)
# → Erro 429: Muitas requisições
```

---

## 📊 MONITORAMENTO

### Ver Logs de Acesso

```bash
# Logs do Laravel
tail -f storage/logs/laravel.log

# Filtrar streaming
tail -f storage/logs/laravel.log | grep "Stream"

# Saída esperada:
# [2024-09-16 10:30:45] local.INFO: Stream iniciado {"user_id":1,"video_id":5,"ip":"201.x.x.x"}
```

### Ver Acessos (Admin)

```bash
# Via API
curl -X GET http://localhost:8000/api/admin/videos/1/access-log \
  -H "Authorization: Bearer ADMIN_TOKEN"
```

### Bloquear Usuário Suspeito

```bash
curl -X POST http://localhost:8000/api/admin/users/5/block-stream \
  -H "Authorization: Bearer ADMIN_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "hours": 24,
    "reason": "Múltiplos IPs detectados"
  }'
```

---

## 🐛 TROUBLESHOOTING

### Problema: "Token inválido"

```
✓ Verificar se token JWT é válido
✓ Verificar se token não expirou
✓ Verificar header Authorization: Bearer TOKEN
```

### Problema: "IP diferente"

```
✓ Normal: mudar de Wi-Fi para móvel
✓ Solução: esperar 5 minutos antes de acessar de novo
✓ Se bloqueado: contato suporte
```

### Problema: "Erro 429 - Rate limit"

```
✓ Muito rápido demais
✓ Máx 5 requisições por minuto
✓ Esperar 1 minuto e tentar novamente
```

### Problema: Player não reproduz

```
✓ Verificar se arquivo de vídeo existe
✓ Verificar permissões pasta storage/app/videos
✓ Verificar header Content-Type: video/mp4
✓ Verificar logs: php artisan tinker
```

---

## 🎯 CHECKLIST FINAL

- [ ] VideoStreamController.php copiado
- [ ] Rotas adicionadas em routes/api.php
- [ ] Widget Flutter importado
- [ ] pubspec.yaml atualizado
- [ ] Migration de termos criada
- [ ] Controller TermsController criado
- [ ] Modal de termos funcionando
- [ ] Testes passando
- [ ] Logs funcionando
- [ ] Termos de Uso publicados
- [ ] Alunos informados sobre restrições

---

## 📞 SUPORTE

**Dúvidas na implementação?**

- Verificar logs: `tail -f storage/logs/laravel.log`
- Verificar database: `php artisan tinker`
- Testar rotas: `php artisan route:list | grep stream`

---

## 🎓 COMO USAR

### Para Aluno

```
1. Acessa app/site
2. Vê notificação: "Aceitar Termos?"
3. Clica "Aceito"
4. Assiste vídeo na tela
   ↓
5. NÃO consegue:
   - Baixar arquivo
   - Fazer print
   - Gravar tela
   - Compartilhar link
```

### Para Professor

```
1. Publica vídeo na plataforma
2. Sistema automaticamente protege
3. Alunos só conseguem assistir
4. Compartilhamento = bloqueio automático
```

### Para Admin

```
1. Monitora acessos
2. Vê histórico de quem assistiu
3. Se suspeita: bloqueia usuário
4. Desbloqueia após 24h ou manualmente
```

---

**Status: ✅ PRONTO PARA PRODUÇÃO**

Implementar, testar e ativar!

