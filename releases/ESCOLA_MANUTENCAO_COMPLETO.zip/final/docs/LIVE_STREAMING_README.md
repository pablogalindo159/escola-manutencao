# 🔴 LIVE STREAMING - YouTube Integração

**Status**: ✅ PRONTO PARA USAR  
**Tipo**: YouTube Embed (Gratuito, Simples, Eficaz)  
**Stack**: Laravel + Flutter + Tailwind  

---

## 📁 Arquivos Inclusos

```
live-streaming/
├── README.md                                    (este arquivo)
├── INSTALL.md                                   (guia de instalação completo)
├── 
├── Backend (Laravel)
│   ├── 2024_09_16_create_live_streams_table.php  (migration)
│   ├── LiveStream.php                            (model)
│   ├── LiveStreamController.php                  (API controller)
│   └── routes.php                                (rotas)
│
├── Frontend Web (Blade)
│   ├── live-stream-player.blade.php              (player para alunos)
│   ├── admin-live-streams.blade.php              (dashboard admin)
│   └── live-stream-form.blade.php                (form criar/editar)
│
├── Frontend Mobile (Flutter)
│   └── live_stream_widget.dart                   (widgets Flutter)
│
└── Documentação
    └── (este arquivo)
```

---

## 🎯 O QUE VOCÊ CONSEGUE FAZER

### ✅ Funcionalidades

- ✅ Agendar transmissões ao vivo
- ✅ Exibir player YouTube embedado
- ✅ Chat integrado do YouTube
- ✅ Estatísticas (visualizadores, curtidas)
- ✅ Admin dashboard completo
- ✅ Suporte a múltiplas transmissões simultâneas
- ✅ Status: agendada → ao vivo → arquivada
- ✅ Gravações salvas automaticamente no YouTube
- ✅ 100% Grátis (usa YouTube)

---

## 🚀 INÍCIO RÁPIDO

### 1️⃣ Instalar

```bash
# Copiar arquivos
cp mega-pack/live-streaming/LiveStream.php app/Models/
cp mega-pack/live-streaming/LiveStreamController.php app/Http/Controllers/API/

# Migration
cp mega-pack/live-streaming/2024_09_16_create_live_streams_table.php database/migrations/
php artisan migrate

# Views
cp mega-pack/live-streaming/*.blade.php resources/views/
```

### 2️⃣ Rotas

Adicionar em `routes/api.php`:

```php
Route::get('/live-streams', [LiveStreamController::class, 'index']);
Route::get('/live-streams/live-now', [LiveStreamController::class, 'liveNow']);
Route::get('/live-streams/{id}', [LiveStreamController::class, 'show']);
```

### 3️⃣ Usar

```php
// Agendar transmissão
$stream = LiveStream::create([
    'user_id' => 1,
    'title' => 'Live Q&A',
    'scheduled_at' => '2024-12-20 19:00:00',
]);

// Obter ao vivo agora
$live = LiveStream::liveNow()->get();

// Iniciar
$stream->markAsLive();

// Finalizar
$stream->markAsEnded();
```

---

## 🎬 FLUXO DE USO

### Professor

1. **Agende aqui** → vai para `/admin/live-streams/create`
2. **Preencha**:
   - Título
   - Descrição
   - Data e hora
   - (Video ID depois)
3. **No YouTube Studio** → crie transmissão ao vivo
4. **Copie o Video ID** → cole aqui
5. **Clique "Iniciar"** → começa a transmissão
6. **Alunos veem ao vivo** → no app/site
7. **Clique "Finalizar"** → encerra

### Aluno

1. **Vê transmissões agendadas** → `/live-streams`
2. **Clica na que tá ao vivo** → vê player YouTube
3. **Assiste e comenta** → chat do YouTube
4. **Depois** → assiste a gravação

---

## 📊 API ENDPOINTS

### Públicos (qualquer um)

```
GET    /api/live-streams                 → listar tudo
GET    /api/live-streams/live-now        → só as ao vivo
GET    /api/live-streams/upcoming        → próximas agendadas
GET    /api/live-streams/recent          → últimas 7 dias
GET    /api/live-streams/{id}            → detalhe
GET    /api/live-streams/{id}/stats      → estatísticas
```

### Autenticados (professores + admin)

```
POST   /api/live-streams                 → criar
PUT    /api/live-streams/{id}            → editar
POST   /api/live-streams/{id}/start      → iniciar
POST   /api/live-streams/{id}/end        → finalizar
DELETE /api/live-streams/{id}            → deletar
```

---

## 🎨 Model LiveStream

### Campos

```php
$stream->id                    // ID da transmissão
$stream->user_id              // Professor (FK)
$stream->title                // Título
$stream->description          // Descrição
$stream->course_id            // Curso (opcional)
$stream->youtube_video_id     // Video ID YouTube
$stream->status               // scheduled, live, ended, archived
$stream->scheduled_at         // Data/hora agendada
$stream->started_at           // Data/hora início real
$stream->ended_at             // Data/hora fim real
$stream->viewers_count        // Assistindo agora
$stream->total_viewers        // Total que assistiu
$stream->likes                // Curtidas
$stream->allow_chat           // Chat habilitado?
$stream->recorded             // Gravada no YouTube?
```

### Métodos Úteis

```php
// Getters
$stream->getEmbedUrl()        // URL para iframe
$stream->getYoutubeUrl()      // URL completa YouTube
$stream->isLive()             // está ao vivo?
$stream->hasStarted()         // já começou?
$stream->getDurationMinutes() // duração em minutos

// Setters
$stream->markAsLive()         // marca como ao vivo
$stream->markAsEnded()        // marca como finalizada
$stream->markAsArchived()     // marca como arquivada

// Scopes
LiveStream::upcoming($limit)  // próximas agendadas
LiveStream::liveNow()         // ao vivo agora
LiveStream::recent($limit)    // recentes (7 dias)
```

---

## 📱 Flutter

### Importar

```dart
import 'package:escolamanutencao/widgets/live_stream_widget.dart';

// Ao vivo
LiveStreamWidget(
  streamId: '1',
  title: 'Live Q&A',
  description: 'Perguntas ao vivo',
  professorName: 'João',
  scheduledAt: DateTime.now(),
  status: 'live',
  viewersCount: 150,
  totalViewers: 250,
  likes: 45,
  allowChat: true,
  youtubeVideoId: 'dQw4w9WgXcQ',
)

// Lista
LiveStreamsListWidget(
  streams: myStreams,
  isLoading: false,
  onRefresh: _refreshStreams,
)
```

---

## 🔒 Segurança

- ✅ Apenas professores podem criar
- ✅ Apenas criador ou admin podem editar
- ✅ Alunos veem apenas públicas
- ✅ Chat é gerenciado pelo YouTube
- ✅ Sem armazenamento de vídeos (YouTube cuida)

---

## 💰 Custos

| Item | Custo |
|------|-------|
| YouTube API | Grátis (até limites generosos) |
| Hosting vídeo | Grátis (YouTube) |
| Plataforma | Já incluso (Laravel) |
| **Total** | **R$ 0** |

---

## 📈 Escalabilidade

- ✅ Suporta 1 transmissão ou 1000
- ✅ YouTube cuida da infra de streaming
- ✅ Seu servidor só gerencia metadados
- ✅ Zero custo de banda

---

## 🔄 Padrão de Resposta API

### Sucesso

```json
{
  "success": true,
  "message": "Transmissão ao vivo iniciada!",
  "data": {
    "id": 1,
    "title": "Live Q&A",
    "status": "live",
    "viewers_count": 150,
    "youtube_video_id": "dQw4w9WgXcQ",
    "youtube_url": "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  }
}
```

### Erro

```json
{
  "success": false,
  "message": "YouTube Video ID é obrigatório para iniciar"
}
```

---

## 🛠️ Customizações Comuns

### Adicionar selo "Exclusivo para Membros"

```blade
@if($stream->course_id)
  <span class="bg-purple-600 text-white px-3 py-1 rounded text-sm">
    Exclusivo: {{ $stream->course->name }}
  </span>
@endif
```

### Enviar notificação quando vai começar

```php
// Event listener
public function handle(LiveStreamStarting $event)
{
    $stream = $event->stream;
    
    $stream->user->course->students->each(function ($student) use ($stream) {
        Notification::send($student, new LiveStreamNotification($stream));
    });
}
```

### Filtrar por curso

```php
Route::get('/courses/{courseId}/live-streams', function ($courseId) {
    return LiveStream::where('course_id', $courseId)
        ->where('status', '!=', 'scheduled')
        ->get();
});
```

---

## 📞 Suporte

- **Problema com streaming?** → Verificar YouTube Studio
- **Video não aparece?** → Verificar Video ID
- **Chat não funciona?** → Conferir se `allow_chat = true`
- **Contadores não atualizam?** → Esperar 24h (API do YouTube)

---

## 🎉 Pronto!

Sua plataforma agora suporta transmissões ao vivo! 

```
$ php artisan migrate
$ flutter pub get
$ npm run dev
# 🚀 LIVE!
```

---

**Pablo, você está pronto para transmitir!** 📡

Qualquer dúvida sobre integração, é só chamar! 🚀

