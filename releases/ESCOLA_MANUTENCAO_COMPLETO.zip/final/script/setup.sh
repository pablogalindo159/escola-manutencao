#!/bin/bash

# ============================================
# ESCOLA DA MANUTENÇÃO - SETUP AUTOMÁTICO
# ============================================
# Execute: bash setup.sh
# Tempo: ~5 minutos
# ============================================

set -e

echo "🚀 ESCOLA DA MANUTENÇÃO - SETUP AUTOMÁTICO"
echo "=========================================="
echo ""

# Cores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

# Funções helper
log_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

log_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

log_error() {
    echo -e "${RED}❌ $1${NC}"
    exit 1
}

log_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

# ============================================
# 1. VERIFICAR PRÉ-REQUISITOS
# ============================================
echo ""
echo "📋 VERIFICANDO PRÉ-REQUISITOS..."
echo ""

# Docker
if ! command -v docker &> /dev/null; then
    log_error "Docker não encontrado. Instale: https://www.docker.com/products/docker-desktop"
fi
log_success "Docker instalado"

# Docker Compose
if ! command -v docker-compose &> /dev/null; then
    log_error "Docker Compose não encontrado"
fi
log_success "Docker Compose instalado"

# ============================================
# 2. CRIAR ARQUIVO .env
# ============================================
echo ""
echo "⚙️  CONFIGURANDO ARQUIVO .env..."
echo ""

if [ ! -f ".env" ]; then
    if [ -f ".env.example" ]; then
        cp .env.example .env
        log_success ".env criado"
    fi
fi

# ============================================
# 3. INICIAR DOCKER
# ============================================
echo ""
echo "🐳 INICIANDO DOCKER..."
echo ""

docker-compose up -d
sleep 10

log_success "Containers rodando"

# ============================================
# 4. INSTALAR DEPENDÊNCIAS
# ============================================
echo ""
echo "📦 INSTALANDO DEPENDÊNCIAS..."
echo ""

docker-compose exec -T laravel composer install
docker-compose exec -T laravel php artisan key:generate
docker-compose exec -T laravel php artisan jwt:secret --force
docker-compose exec -T laravel php artisan migrate --force
docker-compose exec -T laravel php artisan db:seed --force

log_success "Setup Laravel concluído"

# ============================================
# 5. COMPILAR ASSETS
# ============================================
echo ""
echo "🎨 COMPILANDO ASSETS..."
echo ""

if [ -f "package.json" ]; then
    docker-compose exec -T laravel npm install
    docker-compose exec -T laravel npm run build
    log_success "Assets compilados"
fi

# ============================================
# 6. STORAGE LINK
# ============================================
echo ""
docker-compose exec -T laravel php artisan storage:link
log_success "Storage link criado"

# ============================================
# 7. RESUMO FINAL
# ============================================
echo ""
echo "════════════════════════════════════════"
echo "🎉 SETUP CONCLUÍDO!"
echo "════════════════════════════════════════"
echo ""
echo "🌐 Acessar:"
echo "   • Website:  http://localhost:8000"
echo "   • Admin:    http://localhost:8000/admin"
echo "   • API Docs: http://localhost:8000/api/docs"
echo ""
echo "👤 Login:"
echo "   • Email:    admin@example.com"
echo "   • Password: password"
echo ""
echo "📱 App Flutter:"
echo "   cd app"
echo "   flutterfire configure"
echo "   flutter run"
echo ""
